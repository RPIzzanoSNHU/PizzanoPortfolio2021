﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections.Specialized;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public event System.Windows.Forms.ItemDragEventHandler ItemDrag;

        public Form1()
        {
            InitializeComponent();
        }
        bool privateDrag = true;
        private void listView1_ItemDrag(object sender, ItemDragEventArgs e)
        {
            privateDrag = true;
            DoDragDrop(e.Item, DragDropEffects.Copy);
            privateDrag = false;
        }
        private void listView1_DragEnter(object sender, DragEventArgs e)
        {
            if (privateDrag) e.Effect = e.AllowedEffect;
        }
        private void listView1_DragOver(object sender, DragEventArgs e)
        {
            ListViewItem temp = (ListViewItem)e.Data.GetData(typeof(ListViewItem));
        }
        private void listView1_Drop(object sender, DragEventArgs e)
        {
            DataObject obj = e.Data as DataObject;
            StringCollection fileNames = obj.GetFileDropList();
            if (fileNames == null)
            {
                MessageBox.Show("null");
            }
            // test if null
            foreach (string temp in fileNames)
            {
                if (System.IO.Path.GetExtension(temp).Length > 0)
                {
                    this.listView1.Items.Add(temp);
                    if (temp != null)
                    {
                        MessageBox.Show("True");
                    }
                }

                else
                {
                    if (Directory.Exists(temp))
                    {
                        string[] fileEntry = Directory.GetFiles(temp);
                        foreach (string fileName in fileEntry)
                        {
                            this.listView1.Items.Add(fileName);
                        getSubDirect(temp);
                    }
                       // getSubDirect(temp);
                        void getSubDirect(string subdir)
                        {
                            string[] subDirEntry = Directory.GetDirectories(subdir);
                            foreach (string subdirname in subDirEntry) 
                            {
                                this.listView1.Items.Add(subdirname);

                                string[] subfilentry = Directory.GetFiles(subdirname);
                                foreach (string subfilename in subfilentry)
                                {
                                    this.listView1.Items.Add(subfilename);
                                    if (subfilename != null)
                                    {
                                        MessageBox.Show("True");
                                    }
                                }

                                getSubDirect(subdirname);

                            }
                        }
                    }
                }
            }

        }
    }
}