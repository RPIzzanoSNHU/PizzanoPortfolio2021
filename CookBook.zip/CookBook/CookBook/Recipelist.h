#pragma once
#include "ViewRecipe.h"
#include "AddRecipe.h"
#include "Recipe.h"
#include "CookBook.h"
#include "UpdateRecipe.h"
//#include "CookBook.cpp"

namespace CookBook {

	using namespace std;
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Recipelist
	/// </summary>
	public ref class Recipelist : public System::Windows::Forms::Form
	{
	public:
		Recipelist(void);

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Recipelist()
		{
			if (components)
			{
				delete components;
			}
		}
	// Used to access the Cookbook functions
	private: Recipes::CookBook^ MyCookBook;

	private: System::Windows::Forms::DataGridView^  dataGridView1;
	private: System::Windows::Forms::Button^  Add_Recipe;
	private: System::Windows::Forms::Button^  View_Recipe;
	private: System::Windows::Forms::Button^  RefreshListButton;
	private: System::Windows::Forms::Button^  Delete_Recipe;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Button^  Search_Recipe;
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	private: System::Windows::Forms::Button^  Button_Close;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Name;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  PrepTime;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Tags;
	private: System::Windows::Forms::Button^  RefreshButton;
	private: System::Windows::Forms::Label^  label1;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Recipelist::typeid));
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->Name = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->PrepTime = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Tags = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Add_Recipe = (gcnew System::Windows::Forms::Button());
			this->View_Recipe = (gcnew System::Windows::Forms::Button());
			this->RefreshListButton = (gcnew System::Windows::Forms::Button());
			this->Delete_Recipe = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->Search_Recipe = (gcnew System::Windows::Forms::Button());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->Button_Close = (gcnew System::Windows::Forms::Button());
			this->RefreshButton = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// dataGridView1
			// 
			this->dataGridView1->AllowUserToAddRows = false;
			this->dataGridView1->AllowUserToDeleteRows = false;
			this->dataGridView1->BackgroundColor = System::Drawing::Color::White;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(3) {
				this->Name, this->PrepTime,
					this->Tags
			});
			this->dataGridView1->GridColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->dataGridView1->Location = System::Drawing::Point(12, 130);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->ReadOnly = true;
			this->dataGridView1->RowTemplate->DefaultCellStyle->BackColor = System::Drawing::Color::White;
			this->dataGridView1->RowTemplate->DefaultCellStyle->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->dataGridView1->RowTemplate->DefaultCellStyle->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
			this->dataGridView1->RowTemplate->ReadOnly = true;
			this->dataGridView1->SelectionMode = System::Windows::Forms::DataGridViewSelectionMode::FullRowSelect;
			this->dataGridView1->ShowCellErrors = false;
			this->dataGridView1->ShowCellToolTips = false;
			this->dataGridView1->ShowEditingIcon = false;
			this->dataGridView1->ShowRowErrors = false;
			this->dataGridView1->Size = System::Drawing::Size(620, 406);
			this->dataGridView1->TabIndex = 0;
			// 
			// Name
			// 
			this->Name->AutoSizeMode = System::Windows::Forms::DataGridViewAutoSizeColumnMode::AllCellsExceptHeader;
			this->Name->HeaderText = L"Recipe Name";
			this->Name->MinimumWidth = 200;
			this->Name->Name = L"Name";
			this->Name->ReadOnly = true;
			this->Name->Width = 200;
			// 
			// PrepTime
			// 
			this->PrepTime->AutoSizeMode = System::Windows::Forms::DataGridViewAutoSizeColumnMode::AllCellsExceptHeader;
			this->PrepTime->HeaderText = L"Prep Time";
			this->PrepTime->MinimumWidth = 100;
			this->PrepTime->Name = L"PrepTime";
			this->PrepTime->ReadOnly = true;
			this->PrepTime->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			// 
			// Tags
			// 
			this->Tags->AutoSizeMode = System::Windows::Forms::DataGridViewAutoSizeColumnMode::AllCellsExceptHeader;
			this->Tags->HeaderText = L"Tags";
			this->Tags->MinimumWidth = 276;
			this->Tags->Name = L"Tags";
			this->Tags->ReadOnly = true;
			this->Tags->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Tags->Width = 276;
			// 
			// Add_Recipe
			// 
			this->Add_Recipe->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"Add_Recipe.BackgroundImage")));
			this->Add_Recipe->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->Add_Recipe->FlatAppearance->BorderSize = 0;
			this->Add_Recipe->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Add_Recipe->Font = (gcnew System::Drawing::Font(L"Segoe UI Semibold", 1, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Add_Recipe->ForeColor = System::Drawing::Color::Transparent;
			this->Add_Recipe->Location = System::Drawing::Point(487, 100);
			this->Add_Recipe->Name = L"Add_Recipe";
			this->Add_Recipe->Size = System::Drawing::Size(24, 24);
			this->Add_Recipe->TabIndex = 2;
			this->Add_Recipe->UseVisualStyleBackColor = true;
			this->Add_Recipe->Click += gcnew System::EventHandler(this, &Recipelist::Add_Recipe_Click);
			// 
			// View_Recipe
			// 
			this->View_Recipe->BackColor = System::Drawing::Color::Transparent;
			this->View_Recipe->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"View_Recipe.BackgroundImage")));
			this->View_Recipe->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->View_Recipe->FlatAppearance->BorderSize = 0;
			this->View_Recipe->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->View_Recipe->Location = System::Drawing::Point(547, 100);
			this->View_Recipe->Name = L"View_Recipe";
			this->View_Recipe->Size = System::Drawing::Size(24, 24);
			this->View_Recipe->TabIndex = 3;
			this->View_Recipe->UseVisualStyleBackColor = false;
			this->View_Recipe->Click += gcnew System::EventHandler(this, &Recipelist::View_Recipe_Click);
			// 
			// RefreshListButton
			// 
			this->RefreshListButton->BackColor = System::Drawing::Color::Transparent;
			this->RefreshListButton->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"RefreshListButton.BackgroundImage")));
			this->RefreshListButton->FlatAppearance->BorderSize = 0;
			this->RefreshListButton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->RefreshListButton->Location = System::Drawing::Point(577, 100);
			this->RefreshListButton->Name = L"RefreshListButton";
			this->RefreshListButton->Size = System::Drawing::Size(24, 24);
			this->RefreshListButton->TabIndex = 4;
			this->RefreshListButton->UseVisualStyleBackColor = false;
			this->RefreshListButton->Click += gcnew System::EventHandler(this, &Recipelist::RefreshListButton_Click);
			// 
			// Delete_Recipe
			// 
			this->Delete_Recipe->BackColor = System::Drawing::Color::Transparent;
			this->Delete_Recipe->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"Delete_Recipe.BackgroundImage")));
			this->Delete_Recipe->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->Delete_Recipe->FlatAppearance->BorderSize = 0;
			this->Delete_Recipe->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Delete_Recipe->Font = (gcnew System::Drawing::Font(L"Segoe UI Semibold", 1, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Pixel,
				static_cast<System::Byte>(0)));
			this->Delete_Recipe->ForeColor = System::Drawing::Color::Transparent;
			this->Delete_Recipe->Location = System::Drawing::Point(517, 100);
			this->Delete_Recipe->Name = L"Delete_Recipe";
			this->Delete_Recipe->Size = System::Drawing::Size(24, 24);
			this->Delete_Recipe->TabIndex = 5;
			this->Delete_Recipe->UseVisualStyleBackColor = false;
			this->Delete_Recipe->Click += gcnew System::EventHandler(this, &Recipelist::Delete_Recipe_Click);
			// 
			// textBox1
			// 
			this->textBox1->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->textBox1->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->textBox1->Location = System::Drawing::Point(319, 47);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(225, 22);
			this->textBox1->TabIndex = 6;
			this->textBox1->Visible = false;
			this->textBox1->TextChanged += gcnew System::EventHandler(this, &Recipelist::textBox1_TextChanged);
			// 
			// Search_Recipe
			// 
			this->Search_Recipe->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(105)),
				static_cast<System::Int32>(static_cast<System::Byte>(140)));
			this->Search_Recipe->FlatAppearance->BorderSize = 0;
			this->Search_Recipe->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Search_Recipe->Font = (gcnew System::Drawing::Font(L"Segoe UI", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Search_Recipe->ForeColor = System::Drawing::Color::White;
			this->Search_Recipe->Location = System::Drawing::Point(544, 47);
			this->Search_Recipe->Name = L"Search_Recipe";
			this->Search_Recipe->Size = System::Drawing::Size(86, 22);
			this->Search_Recipe->TabIndex = 7;
			this->Search_Recipe->Text = L"Search";
			this->Search_Recipe->UseVisualStyleBackColor = false;
			this->Search_Recipe->Visible = false;
			this->Search_Recipe->Click += gcnew System::EventHandler(this, &Recipelist::Search_Recipe_Click);
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::Color::Transparent;
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->pictureBox1->Location = System::Drawing::Point(29, 18);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(163, 112);
			this->pictureBox1->TabIndex = 8;
			this->pictureBox1->TabStop = false;
			// 
			// Button_Close
			// 
			this->Button_Close->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(105)),
				static_cast<System::Int32>(static_cast<System::Byte>(140)));
			this->Button_Close->FlatAppearance->BorderSize = 0;
			this->Button_Close->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Button_Close->Font = (gcnew System::Drawing::Font(L"Segoe UI", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Button_Close->ForeColor = System::Drawing::Color::White;
			this->Button_Close->Location = System::Drawing::Point(555, 547);
			this->Button_Close->Name = L"Button_Close";
			this->Button_Close->Size = System::Drawing::Size(75, 23);
			this->Button_Close->TabIndex = 9;
			this->Button_Close->Text = L"Close";
			this->Button_Close->UseVisualStyleBackColor = false;
			this->Button_Close->Click += gcnew System::EventHandler(this, &Recipelist::Button_Close_Click);
			// 
			// RefreshButton
			// 
			this->RefreshButton->BackColor = System::Drawing::Color::Transparent;
			this->RefreshButton->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"RefreshButton.BackgroundImage")));
			this->RefreshButton->FlatAppearance->BorderSize = 0;
			this->RefreshButton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->RefreshButton->Location = System::Drawing::Point(607, 100);
			this->RefreshButton->Name = L"RefreshButton";
			this->RefreshButton->Size = System::Drawing::Size(24, 24);
			this->RefreshButton->TabIndex = 10;
			this->RefreshButton->UseVisualStyleBackColor = false;
			this->RefreshButton->Click += gcnew System::EventHandler(this, &Recipelist::RefreshButton_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::Transparent;
			this->label1->Font = (gcnew System::Drawing::Font(L"Segoe Print", 15.75F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)),
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(105)),
				static_cast<System::Int32>(static_cast<System::Byte>(140)));
			this->label1->Location = System::Drawing::Point(33, 90);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(64, 37);
			this->label1->TabIndex = 11;
			this->label1->Text = L"Chef";
			// 
			// Recipelist
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(644, 580);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->RefreshButton);
			this->Controls->Add(this->Button_Close);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->Search_Recipe);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->Delete_Recipe);
			this->Controls->Add(this->RefreshListButton);
			this->Controls->Add(this->View_Recipe);
			this->Controls->Add(this->Add_Recipe);
			this->Controls->Add(this->dataGridView1);
			this->Font = (gcnew System::Drawing::Font(L"Segoe UI Semibold", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			/*this->Name = L"Recipelist";*/
			this->Text = L"Chef";
			this->Load += gcnew System::EventHandler(this, &Recipelist::Recipelist_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

/// <summary>
/// This function Refreshes the list of recipes
/// </summary>
public: Void RefreshList()
{
	// Clear the current list
	dataGridView1->Rows->Clear();

	// Load in the new recipes
	List<Recipe^>^ recipes = MyCookBook->LoadAllRecipes();

	// Display the list
	for each(Recipe^ r in recipes)
	{
		String^ tags = "";
		tags = tags->Join(", ", r->Tags.ToArray());
		dataGridView1->Rows->Add(r->RecipeName, r->PrepTime, tags);
	}
}

/// <summary>
/// This function is called on the initial load
/// </summary>
private: System::Void Recipelist_Load(System::Object^  sender, System::EventArgs^  e);

/// <summary>
/// This function loads the view recipe dialog
/// </summary>
private: System::Void View_Recipe_Click(System::Object^  sender, System::EventArgs^  e) 
{
	DataGridViewRow^ row = dataGridView1->CurrentRow;
	Recipe^ recipeToView = MyCookBook->ReadRecipe((String^)row->Cells[0]->Value);
	ViewRecipe^ ViewRecipeDlg = gcnew ViewRecipe();

	ViewRecipeDlg->SetRecipe(recipeToView);
	ViewRecipeDlg->Show();	
}

/// <summary>
/// This function loads the add recipe dialog
/// </summary>
private: System::Void Add_Recipe_Click(System::Object^  sender, System::EventArgs^  e) {
	AddRecipe^ AddDlg = gcnew AddRecipe(this);

	AddDlg->Show();
}

/// <summary>
/// This function deletes the selected recipe
/// </summary>
private: System::Void Delete_Recipe_Click(System::Object^  sender, System::EventArgs^  e) {
	DataGridViewRow^ row = dataGridView1->CurrentRow;
	MyCookBook->RemoveRecipe((String^)row->Cells[0]->Value);
	RefreshList();
}

/// <summary>
/// This is the function for the close button
/// </summary>
private: System::Void Button_Close_Click(System::Object^  sender, System::EventArgs^  e) {
	this->Close();
}

/// <summary>
/// This is the function for doing a manual refresh
/// </summary>
private: System::Void RefreshButton_Click(System::Object^  sender, System::EventArgs^  e) {
	RefreshList();
}
private: System::Void RefreshListButton_Click(System::Object^  sender, System::EventArgs^  e) {
	DataGridViewRow^ row = dataGridView1->CurrentRow;
	Recipe^ recipeToView = MyCookBook->ReadRecipe((String^)row->Cells[0]->Value);

	UpdateRecipe^ UpdateDlg = gcnew UpdateRecipe();

	UpdateDlg->SetRecipe(recipeToView);
	UpdateDlg->Show();

}
	private: System::Void Search_Recipe_Click(System::Object^  sender, System::EventArgs^  e) {
		/*int tag_dir = 0;
		String^LoadRecipesWithTag = textBox1->Text;
		dataGridView1->Text = LoadRecipesWithTag;
		RefreshList();
		*/
	}
private: System::Void textBox1_TextChanged(System::Object^  sender, System::EventArgs^  e) {
}
};
}
