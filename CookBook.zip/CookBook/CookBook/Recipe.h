#pragma once
namespace Recipes
{
	using namespace System;
	using namespace System::Collections::Generic;

	public ref struct Ingredient
	{
	public:
		String^ Label;
		String^ Amount;
	};

	public ref class Recipe
	{
	public:
		Recipe();
		Recipe(String^ RecipeName, String^ PrepTime, String^ Tags);

		void AddStep(String^ Step);
		void AddIngredient(Ingredient^ ingredient);

		List<String^> Tags;
		List<String^> Directions;
		List<Ingredient^> Ingredients;
		String^ RecipeName;
		String^ PrepTime;
		String^ Description;
	};
}


