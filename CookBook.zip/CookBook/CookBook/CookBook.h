#pragma once
#include "Recipe.h"
using namespace System;
using namespace System::Collections::Generic;
using namespace Recipes;

namespace Recipes
{
	public ref class CookBook
	{
	public:
		CookBook();
		List<Recipe^>^ LoadRecipesWithTag(String^ Tag);
		List<Recipe^>^ LoadRecipesWithName(String^ Name);
		List<Recipe^>^ LoadAllRecipes();
		bool AddRecipe(Recipe^ recipe);
		bool UpdateRecipe(Recipe^ recipe, String^ OldRecipeName);
		bool RemoveRecipe(String^ recipeName);
		Recipe^ ReadRecipe(String^ RecipeName);

	private:
		List<Recipe^>^ Recipes;
		List<String^>^ AvailableRecipeNames;
		List<String^>^ AvailableTags;

		List<String^>^ ReadTag(String^ Tag);
		bool ReadTagsListFile();
		bool ReadRecipesListFile();
		bool CreateRecipeFileFromRecipe(Recipe^ recipe);
		bool UpdateTag(String^ Tag, String^ RecipeName, bool AddRecipe);
		bool RecipeExists(String^ RecipeName);
		bool RecipeHasTag(String^ Recipe, String^ Tag);
		bool TagExists(String^ RecipeName);
		bool WriteRecipesToTag(String^ Tag, List<String^>^ Recipes);
		bool UpdateRecipeListFile(String^ RecipeName, bool AddRecipe);
		bool WriteRecipesToRecipeList();
		bool DeleteRecipeFile(String^ RecipeName);
	};
}