#include "Recipelist.h"

using namespace System;
using namespace System::Windows::Forms;
using namespace CookBook;

Recipelist::Recipelist()
{
	InitializeComponent();
	this->MyCookBook = gcnew Recipes::CookBook();
}

Void Recipelist::Recipelist_Load(System::Object^  sender, System::EventArgs^  e)
{
	RefreshList();
}

[STAThread]
void Main(array<String^>^ args)
{
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	Recipelist recipe;
	Application::Run(%recipe);

}
