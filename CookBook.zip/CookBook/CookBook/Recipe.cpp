#include "Recipe.h"



namespace Recipes {
	using namespace System;
	Recipe::Recipe()
	{

	}
	Recipe::Recipe(String^ RecipeName, String^ PrepTime, String^ Tags)
	{
		this->RecipeName = RecipeName;
		this->PrepTime = PrepTime;
		
		array<String^>^ split = Tags->Split(gcnew array<String^>{" "}, StringSplitOptions::RemoveEmptyEntries);
		this->Tags.AddRange(split);
	}

	void Recipe::AddStep(String^ Step)
	{
		Directions.Add(Step);
	}

	void Recipe::AddIngredient(Ingredient^ ingredient)
	{
		Ingredients.Add(ingredient);
	}
}

