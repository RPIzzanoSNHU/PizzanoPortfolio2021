#pragma once
#include "Recipe.h"
#include "CookBook.h"

namespace CookBook {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace Recipes;

	/// <summary>
	/// Summary for UpdateRecipe
	/// </summary>
	public ref class UpdateRecipe : public System::Windows::Forms::Form
	{
	public:
		UpdateRecipe()
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
			MyCookBook = gcnew Recipes::CookBook();
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~UpdateRecipe()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	protected:
	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::Button^  CancelButton;
	private: System::Windows::Forms::DataGridView^  DirectionsGridView;

	private: System::Windows::Forms::DataGridView^  IngredientGridView;


	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Button^  SaveButton;
	private: System::Windows::Forms::TextBox^  DirectionTxtBox;
	private: System::Windows::Forms::TextBox^  IngredientAmountTxtBox;
	private: System::Windows::Forms::TextBox^  IngredientNameTxtBox;
	private: System::Windows::Forms::TextBox^  TagsTxtBox;
	private: System::Windows::Forms::TextBox^  PrepTimeTxtBox;
	private: System::Windows::Forms::TextBox^  RecipeNameTxtBox;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Button^  DirectionAddButton;
	private: System::Windows::Forms::Button^  IngredientAddButton;
	private: System::Windows::Forms::Button^  DirectionRemoveButton;
	private: System::Windows::Forms::Button^  IngredientRemoveButton;




	protected:

	private: Recipe^ RecipeToView;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Step;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  IngredientName;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  IngredientAmount;
	private: Recipes::CookBook^ MyCookBook;

	public: void SetRecipe(Recipe^ recipe)
	{
		RecipeToView = gcnew Recipe();

		this->RecipeToView->RecipeName = recipe->RecipeName;
		this->RecipeToView->PrepTime = recipe->PrepTime;

		for each(String^ s in recipe->Tags)
		{
			RecipeToView->Tags.Add(s);
		}

		for each(String^ s in recipe->Directions)
		{
			RecipeToView->AddStep(s);
		}

		for each(Ingredient^ i in recipe->Ingredients)
		{
			RecipeToView->AddIngredient(i);
		}
	}

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(UpdateRecipe::typeid));
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle1 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle2 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle3 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle4 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->CancelButton = (gcnew System::Windows::Forms::Button());
			this->DirectionsGridView = (gcnew System::Windows::Forms::DataGridView());
			this->IngredientGridView = (gcnew System::Windows::Forms::DataGridView());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->SaveButton = (gcnew System::Windows::Forms::Button());
			this->DirectionTxtBox = (gcnew System::Windows::Forms::TextBox());
			this->IngredientAmountTxtBox = (gcnew System::Windows::Forms::TextBox());
			this->IngredientNameTxtBox = (gcnew System::Windows::Forms::TextBox());
			this->TagsTxtBox = (gcnew System::Windows::Forms::TextBox());
			this->PrepTimeTxtBox = (gcnew System::Windows::Forms::TextBox());
			this->RecipeNameTxtBox = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->DirectionAddButton = (gcnew System::Windows::Forms::Button());
			this->IngredientAddButton = (gcnew System::Windows::Forms::Button());
			this->DirectionRemoveButton = (gcnew System::Windows::Forms::Button());
			this->IngredientRemoveButton = (gcnew System::Windows::Forms::Button());
			this->Step = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->IngredientName = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->IngredientAmount = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->DirectionsGridView))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->IngredientGridView))->BeginInit();
			this->SuspendLayout();
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::Color::Transparent;
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->pictureBox1->Location = System::Drawing::Point(528, 10);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(154, 112);
			this->pictureBox1->TabIndex = 51;
			this->pictureBox1->TabStop = false;
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->BackColor = System::Drawing::Color::Transparent;
			this->label9->Font = (gcnew System::Drawing::Font(L"Segoe UI", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label9->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(105)),
				static_cast<System::Int32>(static_cast<System::Byte>(140)));
			this->label9->Location = System::Drawing::Point(8, 9);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(205, 37);
			this->label9->TabIndex = 50;
			this->label9->Text = L"Update Recipe";
			// 
			// CancelButton
			// 
			this->CancelButton->BackColor = System::Drawing::Color::Gray;
			this->CancelButton->FlatAppearance->BorderSize = 0;
			this->CancelButton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->CancelButton->Font = (gcnew System::Drawing::Font(L"Segoe UI", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->CancelButton->ForeColor = System::Drawing::Color::White;
			this->CancelButton->Location = System::Drawing::Point(512, 469);
			this->CancelButton->Name = L"CancelButton";
			this->CancelButton->Size = System::Drawing::Size(92, 34);
			this->CancelButton->TabIndex = 49;
			this->CancelButton->Text = L"Cancel";
			this->CancelButton->UseVisualStyleBackColor = false;
			this->CancelButton->Click += gcnew System::EventHandler(this, &UpdateRecipe::CancelButton_Click);
			// 
			// DirectionsGridView
			// 
			this->DirectionsGridView->AllowUserToAddRows = false;
			this->DirectionsGridView->AllowUserToDeleteRows = false;
			this->DirectionsGridView->BackgroundColor = System::Drawing::Color::White;
			dataGridViewCellStyle1->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle1->BackColor = System::Drawing::Color::White;
			dataGridViewCellStyle1->Font = (gcnew System::Drawing::Font(L"Segoe UI Semibold", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			dataGridViewCellStyle1->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			dataGridViewCellStyle1->SelectionBackColor = System::Drawing::Color::SteelBlue;
			dataGridViewCellStyle1->SelectionForeColor = System::Drawing::Color::White;
			dataGridViewCellStyle1->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
			this->DirectionsGridView->ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this->DirectionsGridView->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->DirectionsGridView->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) { this->Step });
			this->DirectionsGridView->GridColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->DirectionsGridView->Location = System::Drawing::Point(362, 178);
			this->DirectionsGridView->MultiSelect = false;
			this->DirectionsGridView->Name = L"DirectionsGridView";
			this->DirectionsGridView->ReadOnly = true;
			this->DirectionsGridView->RowHeadersBorderStyle = System::Windows::Forms::DataGridViewHeaderBorderStyle::Single;
			dataGridViewCellStyle2->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			dataGridViewCellStyle2->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
			this->DirectionsGridView->RowsDefaultCellStyle = dataGridViewCellStyle2;
			this->DirectionsGridView->RowTemplate->DefaultCellStyle->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
			this->DirectionsGridView->RowTemplate->ReadOnly = true;
			this->DirectionsGridView->RowTemplate->Resizable = System::Windows::Forms::DataGridViewTriState::True;
			this->DirectionsGridView->SelectionMode = System::Windows::Forms::DataGridViewSelectionMode::FullRowSelect;
			this->DirectionsGridView->ShowCellErrors = false;
			this->DirectionsGridView->ShowCellToolTips = false;
			this->DirectionsGridView->ShowEditingIcon = false;
			this->DirectionsGridView->ShowRowErrors = false;
			this->DirectionsGridView->Size = System::Drawing::Size(340, 267);
			this->DirectionsGridView->TabIndex = 48;
			// 
			// IngredientGridView
			// 
			this->IngredientGridView->AllowUserToAddRows = false;
			this->IngredientGridView->AllowUserToDeleteRows = false;
			this->IngredientGridView->BackgroundColor = System::Drawing::Color::White;
			dataGridViewCellStyle3->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle3->BackColor = System::Drawing::Color::White;
			dataGridViewCellStyle3->Font = (gcnew System::Drawing::Font(L"Segoe UI Semibold", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			dataGridViewCellStyle3->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			dataGridViewCellStyle3->SelectionBackColor = System::Drawing::Color::SteelBlue;
			dataGridViewCellStyle3->SelectionForeColor = System::Drawing::Color::White;
			dataGridViewCellStyle3->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
			this->IngredientGridView->ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
			this->IngredientGridView->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->IngredientGridView->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) {
				this->IngredientName,
					this->IngredientAmount
			});
			this->IngredientGridView->GridColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->IngredientGridView->Location = System::Drawing::Point(12, 280);
			this->IngredientGridView->MultiSelect = false;
			this->IngredientGridView->Name = L"IngredientGridView";
			this->IngredientGridView->ReadOnly = true;
			dataGridViewCellStyle4->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			dataGridViewCellStyle4->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
			this->IngredientGridView->RowsDefaultCellStyle = dataGridViewCellStyle4;
			this->IngredientGridView->RowTemplate->DefaultCellStyle->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
			this->IngredientGridView->SelectionMode = System::Windows::Forms::DataGridViewSelectionMode::FullRowSelect;
			this->IngredientGridView->ShowCellErrors = false;
			this->IngredientGridView->ShowCellToolTips = false;
			this->IngredientGridView->ShowEditingIcon = false;
			this->IngredientGridView->ShowRowErrors = false;
			this->IngredientGridView->Size = System::Drawing::Size(334, 223);
			this->IngredientGridView->TabIndex = 47;
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->BackColor = System::Drawing::Color::Transparent;
			this->label8->Font = (gcnew System::Drawing::Font(L"Segoe UI Semibold", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label8->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->label8->Location = System::Drawing::Point(215, 106);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(132, 13);
			this->label8->TabIndex = 46;
			this->label8->Text = L"Separate with Semicolon";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->BackColor = System::Drawing::Color::Transparent;
			this->label7->Font = (gcnew System::Drawing::Font(L"Segoe UI Semibold", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->label7->Location = System::Drawing::Point(14, 208);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(125, 17);
			this->label7->TabIndex = 45;
			this->label7->Text = L"Ingredient Amount";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->BackColor = System::Drawing::Color::Transparent;
			this->label3->Font = (gcnew System::Drawing::Font(L"Segoe UI Semibold", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->label3->Location = System::Drawing::Point(15, 166);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(111, 17);
			this->label3->TabIndex = 44;
			this->label3->Text = L"Ingredient Name";
			// 
			// SaveButton
			// 
			this->SaveButton->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(105)),
				static_cast<System::Int32>(static_cast<System::Byte>(140)));
			this->SaveButton->FlatAppearance->BorderSize = 0;
			this->SaveButton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->SaveButton->Font = (gcnew System::Drawing::Font(L"Segoe UI", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->SaveButton->ForeColor = System::Drawing::Color::White;
			this->SaveButton->Location = System::Drawing::Point(610, 469);
			this->SaveButton->Name = L"SaveButton";
			this->SaveButton->Size = System::Drawing::Size(92, 34);
			this->SaveButton->TabIndex = 43;
			this->SaveButton->Text = L"Save Recipe";
			this->SaveButton->UseVisualStyleBackColor = false;
			this->SaveButton->Click += gcnew System::EventHandler(this, &UpdateRecipe::SaveButton_Click);
			// 
			// DirectionTxtBox
			// 
			this->DirectionTxtBox->BackColor = System::Drawing::Color::White;
			this->DirectionTxtBox->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->DirectionTxtBox->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->DirectionTxtBox->Location = System::Drawing::Point(359, 122);
			this->DirectionTxtBox->Name = L"DirectionTxtBox";
			this->DirectionTxtBox->Size = System::Drawing::Size(343, 22);
			this->DirectionTxtBox->TabIndex = 42;
			// 
			// IngredientAmountTxtBox
			// 
			this->IngredientAmountTxtBox->BackColor = System::Drawing::Color::White;
			this->IngredientAmountTxtBox->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->IngredientAmountTxtBox->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->IngredientAmountTxtBox->Location = System::Drawing::Point(16, 226);
			this->IngredientAmountTxtBox->Name = L"IngredientAmountTxtBox";
			this->IngredientAmountTxtBox->Size = System::Drawing::Size(331, 22);
			this->IngredientAmountTxtBox->TabIndex = 41;
			// 
			// IngredientNameTxtBox
			// 
			this->IngredientNameTxtBox->BackColor = System::Drawing::Color::White;
			this->IngredientNameTxtBox->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->IngredientNameTxtBox->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->IngredientNameTxtBox->Location = System::Drawing::Point(16, 184);
			this->IngredientNameTxtBox->Name = L"IngredientNameTxtBox";
			this->IngredientNameTxtBox->Size = System::Drawing::Size(331, 22);
			this->IngredientNameTxtBox->TabIndex = 40;
			this->IngredientNameTxtBox->Tag = L"";
			// 
			// TagsTxtBox
			// 
			this->TagsTxtBox->BackColor = System::Drawing::Color::White;
			this->TagsTxtBox->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->TagsTxtBox->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->TagsTxtBox->Location = System::Drawing::Point(15, 122);
			this->TagsTxtBox->Name = L"TagsTxtBox";
			this->TagsTxtBox->Size = System::Drawing::Size(331, 22);
			this->TagsTxtBox->TabIndex = 39;
			// 
			// PrepTimeTxtBox
			// 
			this->PrepTimeTxtBox->BackColor = System::Drawing::Color::White;
			this->PrepTimeTxtBox->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->PrepTimeTxtBox->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->PrepTimeTxtBox->Location = System::Drawing::Point(359, 76);
			this->PrepTimeTxtBox->Name = L"PrepTimeTxtBox";
			this->PrepTimeTxtBox->Size = System::Drawing::Size(136, 22);
			this->PrepTimeTxtBox->TabIndex = 38;
			// 
			// RecipeNameTxtBox
			// 
			this->RecipeNameTxtBox->BackColor = System::Drawing::Color::White;
			this->RecipeNameTxtBox->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->RecipeNameTxtBox->Font = (gcnew System::Drawing::Font(L"Segoe UI Semibold", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->RecipeNameTxtBox->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->RecipeNameTxtBox->Location = System::Drawing::Point(15, 77);
			this->RecipeNameTxtBox->Name = L"RecipeNameTxtBox";
			this->RecipeNameTxtBox->Size = System::Drawing::Size(331, 22);
			this->RecipeNameTxtBox->TabIndex = 37;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->BackColor = System::Drawing::Color::Transparent;
			this->label6->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->label6->Location = System::Drawing::Point(14, 151);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(104, 17);
			this->label6->TabIndex = 36;
			this->label6->Text = L"Add Ingridients";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->BackColor = System::Drawing::Color::Transparent;
			this->label5->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->label5->Location = System::Drawing::Point(13, 103);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(37, 17);
			this->label5->TabIndex = 35;
			this->label5->Text = L"Tags";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->BackColor = System::Drawing::Color::Transparent;
			this->label4->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->label4->Location = System::Drawing::Point(356, 59);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(71, 17);
			this->label4->TabIndex = 34;
			this->label4->Text = L"Prep Time";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::Color::Transparent;
			this->label2->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->label2->Location = System::Drawing::Point(356, 103);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(100, 17);
			this->label2->TabIndex = 33;
			this->label2->Text = L"Add Directions";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::Transparent;
			this->label1->Cursor = System::Windows::Forms::Cursors::Default;
			this->label1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label1->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->label1->Location = System::Drawing::Point(13, 58);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(88, 17);
			this->label1->TabIndex = 32;
			this->label1->Text = L"Recipe Name";
			// 
			// DirectionAddButton
			// 
			this->DirectionAddButton->BackColor = System::Drawing::Color::Transparent;
			this->DirectionAddButton->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"DirectionAddButton.BackgroundImage")));
			this->DirectionAddButton->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->DirectionAddButton->FlatAppearance->BorderSize = 0;
			this->DirectionAddButton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->DirectionAddButton->Location = System::Drawing::Point(542, 150);
			this->DirectionAddButton->Name = L"DirectionAddButton";
			this->DirectionAddButton->Size = System::Drawing::Size(24, 24);
			this->DirectionAddButton->TabIndex = 31;
			this->DirectionAddButton->UseVisualStyleBackColor = false;
			this->DirectionAddButton->Click += gcnew System::EventHandler(this, &UpdateRecipe::DirectionAddButton_Click_1);
			// 
			// IngredientAddButton
			// 
			this->IngredientAddButton->BackColor = System::Drawing::Color::Transparent;
			this->IngredientAddButton->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"IngredientAddButton.BackgroundImage")));
			this->IngredientAddButton->FlatAppearance->BorderSize = 0;
			this->IngredientAddButton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->IngredientAddButton->Location = System::Drawing::Point(181, 252);
			this->IngredientAddButton->Name = L"IngredientAddButton";
			this->IngredientAddButton->Size = System::Drawing::Size(24, 24);
			this->IngredientAddButton->TabIndex = 30;
			this->IngredientAddButton->UseVisualStyleBackColor = false;
			this->IngredientAddButton->Click += gcnew System::EventHandler(this, &UpdateRecipe::IngredientAddButton_Click);
			// 
			// DirectionRemoveButton
			// 
			this->DirectionRemoveButton->BackColor = System::Drawing::Color::Transparent;
			this->DirectionRemoveButton->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"DirectionRemoveButton.BackgroundImage")));
			this->DirectionRemoveButton->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->DirectionRemoveButton->FlatAppearance->BorderSize = 0;
			this->DirectionRemoveButton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->DirectionRemoveButton->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->DirectionRemoveButton->Location = System::Drawing::Point(512, 150);
			this->DirectionRemoveButton->Name = L"DirectionRemoveButton";
			this->DirectionRemoveButton->Size = System::Drawing::Size(24, 24);
			this->DirectionRemoveButton->TabIndex = 29;
			this->DirectionRemoveButton->UseVisualStyleBackColor = false;
			this->DirectionRemoveButton->Click += gcnew System::EventHandler(this, &UpdateRecipe::DirectionRemoveButton_Click_1);
			// 
			// IngredientRemoveButton
			// 
			this->IngredientRemoveButton->BackColor = System::Drawing::Color::Transparent;
			this->IngredientRemoveButton->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"IngredientRemoveButton.BackgroundImage")));
			this->IngredientRemoveButton->FlatAppearance->BorderSize = 0;
			this->IngredientRemoveButton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->IngredientRemoveButton->Font = (gcnew System::Drawing::Font(L"Segoe UI", 20, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->IngredientRemoveButton->Location = System::Drawing::Point(151, 252);
			this->IngredientRemoveButton->Name = L"IngredientRemoveButton";
			this->IngredientRemoveButton->Size = System::Drawing::Size(24, 24);
			this->IngredientRemoveButton->TabIndex = 28;
			this->IngredientRemoveButton->TextAlign = System::Drawing::ContentAlignment::BottomCenter;
			this->IngredientRemoveButton->UseVisualStyleBackColor = false;
			this->IngredientRemoveButton->Click += gcnew System::EventHandler(this, &UpdateRecipe::IngredientRemoveButton_Click);
			// 
			// Step
			// 
			this->Step->HeaderText = L"Step";
			this->Step->MinimumWidth = 297;
			this->Step->Name = L"Step";
			this->Step->ReadOnly = true;
			this->Step->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Step->Width = 297;
			// 
			// IngredientName
			// 
			this->IngredientName->HeaderText = L"Name";
			this->IngredientName->MinimumWidth = 146;
			this->IngredientName->Name = L"IngredientName";
			this->IngredientName->ReadOnly = true;
			this->IngredientName->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->IngredientName->Width = 146;
			// 
			// IngredientAmount
			// 
			this->IngredientAmount->HeaderText = L"Amount";
			this->IngredientAmount->MinimumWidth = 145;
			this->IngredientAmount->Name = L"IngredientAmount";
			this->IngredientAmount->ReadOnly = true;
			this->IngredientAmount->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->IngredientAmount->Width = 145;
			// 
			// UpdateRecipe
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(710, 512);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->CancelButton);
			this->Controls->Add(this->DirectionsGridView);
			this->Controls->Add(this->IngredientGridView);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->SaveButton);
			this->Controls->Add(this->DirectionTxtBox);
			this->Controls->Add(this->IngredientAmountTxtBox);
			this->Controls->Add(this->IngredientNameTxtBox);
			this->Controls->Add(this->TagsTxtBox);
			this->Controls->Add(this->PrepTimeTxtBox);
			this->Controls->Add(this->RecipeNameTxtBox);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->DirectionAddButton);
			this->Controls->Add(this->IngredientAddButton);
			this->Controls->Add(this->DirectionRemoveButton);
			this->Controls->Add(this->IngredientRemoveButton);
			this->Font = (gcnew System::Drawing::Font(L"Segoe UI Semibold", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"UpdateRecipe";
			this->Text = L"Update Recipe";
			this->Load += gcnew System::EventHandler(this, &UpdateRecipe::UpdateRecipe_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->DirectionsGridView))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->IngredientGridView))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		///<summary>
		/// This function populates the recipe when the dialog loads
		///</summary>
	private: System::Void UpdateRecipe_Load(System::Object^  sender, System::EventArgs^  e) {
		RecipeNameTxtBox->Text = RecipeToView->RecipeName;
		PrepTimeTxtBox->Text = RecipeToView->PrepTime;
		TagsTxtBox->Text = String::Join("; ", RecipeToView->Tags.ToArray());

		// Load all ingredients
		for each(Ingredient^ i in RecipeToView->Ingredients)
		{
			IngredientGridView->Rows->Add(i->Label, i->Amount);
		}

		// Load the directions
		for each(String^ s in RecipeToView->Directions)
		{
			DirectionsGridView->Rows->Add(s);
		}

		DirectionsGridView->AutoResizeRows(DataGridViewAutoSizeRowsMode::AllCellsExceptHeaders);
		IngredientGridView->AutoResizeRows(DataGridViewAutoSizeRowsMode::AllCellsExceptHeaders);
	}
		///<summary>
		/// This function closes the dialog
		///</summary>
private: System::Void CancelButton_Click(System::Object^  sender, System::EventArgs^  e) {
	this->Close();
}
		 ///<summary>
		 /// This function saves the recipe and closes the dialog
		 ///</summary>
private: System::Void SaveButton_Click(System::Object^  sender, System::EventArgs^  e) {
	// Create a new recipe
	Recipe^ newRecipe = gcnew Recipe();

	// Save off the values
	newRecipe->RecipeName = RecipeNameTxtBox->Text;
	newRecipe->PrepTime = PrepTimeTxtBox->Text;

	array<String^>^ splitTags = TagsTxtBox->Text->Split(gcnew array<String^>{";"}, StringSplitOptions::RemoveEmptyEntries);
	for each(String^ s in splitTags)
	{
		newRecipe->Tags.Add(s->Trim()->ToLower());
	}

	for each(DataGridViewRow^ r in IngredientGridView->Rows)
	{
		Ingredient^ i = gcnew Ingredient();
		i->Label = (String^)r->Cells[0]->Value;
		i->Amount = (String^)r->Cells[1]->Value;

		newRecipe->AddIngredient(i);
	}

	for each(DataGridViewRow^ r in DirectionsGridView->Rows)
	{
		newRecipe->AddStep((String^)r->Cells[0]->Value);
	}

	// Update the recipe
	MyCookBook->UpdateRecipe(newRecipe, RecipeToView->RecipeName);

	// Close the dialog
	this->Close();
}

		 ///<summary>
		 ///This function removes an ingredient from the list
		 ///</summary>
private: System::Void IngredientRemoveButton_Click(System::Object^  sender, System::EventArgs^  e) {
	if (IngredientGridView->CurrentRow != nullptr)
	{
		IngredientGridView->Rows->Remove(IngredientGridView->CurrentRow);
	}
}

		 ///<summary>
		 /// This function adds an ingredient to the list
		 ///</summary>
private: System::Void IngredientAddButton_Click(System::Object^  sender, System::EventArgs^  e) {
	IngredientGridView->Rows->Add(IngredientNameTxtBox->Text->Trim(), IngredientAmountTxtBox->Text->Trim());

	IngredientNameTxtBox->Clear();
	IngredientAmountTxtBox->Clear();
	IngredientGridView->AutoResizeRows(DataGridViewAutoSizeRowsMode::AllCellsExceptHeaders);
}

		 ///<summary>
		 /// This function removes a step from the list
		 ///</summary>
private: System::Void DirectionRemoveButton_Click_1(System::Object^  sender, System::EventArgs^  e) {
	if (DirectionsGridView->CurrentRow != nullptr)
	{
		DirectionsGridView->Rows->Remove(DirectionsGridView->CurrentRow);
	}
}

		 ///<summary>
		 /// This function adds a step to the list
		 ///</summary>
private: System::Void DirectionAddButton_Click_1(System::Object^  sender, System::EventArgs^  e) {
	DirectionsGridView->Rows->Add(DirectionTxtBox->Text->Trim());
	DirectionsGridView->AutoSizeRowsMode = DataGridViewAutoSizeRowsMode::AllCellsExceptHeaders;
	DirectionTxtBox->Clear();
}
};
}
