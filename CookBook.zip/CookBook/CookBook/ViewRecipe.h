#pragma once
#include "Recipe.h"

namespace CookBook 
{

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace Recipes;
	// for file printing
	using namespace System::IO;
	/// <summary>
	/// Summary for ViewRecipe
	/// </summary>
	public ref class ViewRecipe : public System::Windows::Forms::Form
	{
	public:
		ViewRecipe(void)
		{
			InitializeComponent();
		}

		//ViewRecipe(Recipe^ r)
		//{
		//	InitializeComponent();
		//	recipe = r;
		//}


	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~ViewRecipe()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  AddTimerButton;
	private: System::Windows::Forms::Button^  RemoveTimerButton;
	protected:

	//private:Recipe^ recipe;

	protected:




	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  RecipeNameTxtBox;


	private: System::Windows::Forms::Timer^  timer1;
	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::TextBox^  textBox3;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Button^  CloseButton;



	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::TextBox^  PrepTimeTxtBox;


	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::DataGridView^  IngredientsGridView;



	private: System::Windows::Forms::DataGridView^  DirectionsGridView;



	private: System::Windows::Forms::TextBox^  TagTxtBox;
	private: System::Windows::Forms::Label^  label8;



	private: System::Windows::Forms::DataGridView^  TimerDataGrid;



	private: System::Windows::Forms::TextBox^  TimerLabelTxtBox;
	private: System::Windows::Forms::Label^  label9;



	private: System::Windows::Forms::PictureBox^  pictureBox1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Timers;


	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Label;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  mins;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  secs;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  IngredientName;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  IngredientAmount;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  dataGridViewTextBoxColumn1;





	private: Recipe^ RecipeToView;

	public: void SetRecipe(Recipe^ recipe)
	{
		RecipeToView = gcnew Recipe();

		this->RecipeToView->RecipeName = recipe->RecipeName;
		this->RecipeToView->PrepTime = recipe->PrepTime;
		
		for each(String^ s in recipe->Tags)
		{
			RecipeToView->Tags.Add(s);
		}
		
		for each(String^ s in recipe->Directions)
		{
			RecipeToView->AddStep(s);
		}

		for each(Ingredient^ i in recipe->Ingredients)
		{
			RecipeToView->AddIngredient(i);
		}
	}

	private: System::ComponentModel::IContainer^  components;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(ViewRecipe::typeid));
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle1 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle2 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle3 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			this->AddTimerButton = (gcnew System::Windows::Forms::Button());
			this->RemoveTimerButton = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->RecipeNameTxtBox = (gcnew System::Windows::Forms::TextBox());
			this->timer1 = (gcnew System::Windows::Forms::Timer(this->components));
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->CloseButton = (gcnew System::Windows::Forms::Button());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->PrepTimeTxtBox = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->IngredientsGridView = (gcnew System::Windows::Forms::DataGridView());
			this->DirectionsGridView = (gcnew System::Windows::Forms::DataGridView());
			this->TagTxtBox = (gcnew System::Windows::Forms::TextBox());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->TimerDataGrid = (gcnew System::Windows::Forms::DataGridView());
			this->Label = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->mins = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->secs = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->TimerLabelTxtBox = (gcnew System::Windows::Forms::TextBox());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->Timers = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->IngredientName = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->IngredientAmount = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->dataGridViewTextBoxColumn1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->IngredientsGridView))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->DirectionsGridView))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->TimerDataGrid))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// AddTimerButton
			// 
			this->AddTimerButton->BackColor = System::Drawing::Color::Transparent;
			this->AddTimerButton->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"AddTimerButton.BackgroundImage")));
			this->AddTimerButton->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->AddTimerButton->FlatAppearance->BorderSize = 0;
			this->AddTimerButton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->AddTimerButton->Location = System::Drawing::Point(385, 317);
			this->AddTimerButton->Name = L"AddTimerButton";
			this->AddTimerButton->Size = System::Drawing::Size(24, 24);
			this->AddTimerButton->TabIndex = 1;
			this->AddTimerButton->UseVisualStyleBackColor = false;
			// 
			// RemoveTimerButton
			// 
			this->RemoveTimerButton->BackColor = System::Drawing::Color::Transparent;
			this->RemoveTimerButton->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"RemoveTimerButton.BackgroundImage")));
			this->RemoveTimerButton->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->RemoveTimerButton->FlatAppearance->BorderSize = 0;
			this->RemoveTimerButton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->RemoveTimerButton->Location = System::Drawing::Point(415, 317);
			this->RemoveTimerButton->Name = L"RemoveTimerButton";
			this->RemoveTimerButton->Size = System::Drawing::Size(24, 24);
			this->RemoveTimerButton->TabIndex = 2;
			this->RemoveTimerButton->UseVisualStyleBackColor = false;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(12, 91);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(78, 17);
			this->label2->TabIndex = 9;
			this->label2->Text = L"Ingredients";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(12, 246);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(71, 17);
			this->label3->TabIndex = 10;
			this->label3->Text = L"Directions";
			// 
			// RecipeNameTxtBox
			// 
			this->RecipeNameTxtBox->BackColor = System::Drawing::Color::White;
			this->RecipeNameTxtBox->Location = System::Drawing::Point(103, 9);
			this->RecipeNameTxtBox->Name = L"RecipeNameTxtBox";
			this->RecipeNameTxtBox->ReadOnly = true;
			this->RecipeNameTxtBox->Size = System::Drawing::Size(172, 22);
			this->RecipeNameTxtBox->TabIndex = 12;
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(322, 376);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(100, 22);
			this->textBox2->TabIndex = 13;
			// 
			// textBox3
			// 
			this->textBox3->Location = System::Drawing::Point(322, 402);
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(100, 22);
			this->textBox3->TabIndex = 14;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(428, 379);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(58, 17);
			this->label1->TabIndex = 15;
			this->label1->Text = L"Minutes";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(428, 405);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(58, 17);
			this->label5->TabIndex = 16;
			this->label5->Text = L"Seconds";
			// 
			// CloseButton
			// 
			this->CloseButton->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(105)),
				static_cast<System::Int32>(static_cast<System::Byte>(140)));
			this->CloseButton->FlatAppearance->BorderSize = 0;
			this->CloseButton->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->CloseButton->ForeColor = System::Drawing::Color::White;
			this->CloseButton->Location = System::Drawing::Point(447, 441);
			this->CloseButton->Name = L"CloseButton";
			this->CloseButton->Size = System::Drawing::Size(78, 25);
			this->CloseButton->TabIndex = 19;
			this->CloseButton->Text = L"Close";
			this->CloseButton->UseVisualStyleBackColor = false;
			this->CloseButton->Click += gcnew System::EventHandler(this, &ViewRecipe::button5_Click);
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(12, 12);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(44, 17);
			this->label6->TabIndex = 20;
			this->label6->Text = L"Name";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->Location = System::Drawing::Point(12, 35);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(71, 17);
			this->label7->TabIndex = 21;
			this->label7->Text = L"Prep Time";
			// 
			// PrepTimeTxtBox
			// 
			this->PrepTimeTxtBox->BackColor = System::Drawing::Color::White;
			this->PrepTimeTxtBox->Location = System::Drawing::Point(103, 34);
			this->PrepTimeTxtBox->Name = L"PrepTimeTxtBox";
			this->PrepTimeTxtBox->ReadOnly = true;
			this->PrepTimeTxtBox->Size = System::Drawing::Size(172, 22);
			this->PrepTimeTxtBox->TabIndex = 22;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(389, 130);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(50, 17);
			this->label4->TabIndex = 24;
			this->label4->Text = L"Timers";
			// 
			// IngredientsGridView
			// 
			this->IngredientsGridView->AllowUserToAddRows = false;
			this->IngredientsGridView->AllowUserToDeleteRows = false;
			this->IngredientsGridView->BackgroundColor = System::Drawing::Color::White;
			this->IngredientsGridView->ColumnHeadersBorderStyle = System::Windows::Forms::DataGridViewHeaderBorderStyle::Single;
			this->IngredientsGridView->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->IngredientsGridView->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) {
				this->IngredientName,
					this->IngredientAmount
			});
			this->IngredientsGridView->GridColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->IngredientsGridView->Location = System::Drawing::Point(12, 111);
			this->IngredientsGridView->Name = L"IngredientsGridView";
			this->IngredientsGridView->ReadOnly = true;
			dataGridViewCellStyle1->BackColor = System::Drawing::Color::White;
			dataGridViewCellStyle1->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			dataGridViewCellStyle1->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
			this->IngredientsGridView->RowsDefaultCellStyle = dataGridViewCellStyle1;
			this->IngredientsGridView->Size = System::Drawing::Size(263, 126);
			this->IngredientsGridView->TabIndex = 25;
			// 
			// DirectionsGridView
			// 
			this->DirectionsGridView->AllowUserToAddRows = false;
			this->DirectionsGridView->AllowUserToDeleteRows = false;
			this->DirectionsGridView->BackgroundColor = System::Drawing::Color::White;
			this->DirectionsGridView->ColumnHeadersBorderStyle = System::Windows::Forms::DataGridViewHeaderBorderStyle::Single;
			this->DirectionsGridView->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->DirectionsGridView->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) { this->dataGridViewTextBoxColumn1 });
			this->DirectionsGridView->GridColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->DirectionsGridView->Location = System::Drawing::Point(12, 266);
			this->DirectionsGridView->Name = L"DirectionsGridView";
			this->DirectionsGridView->ReadOnly = true;
			dataGridViewCellStyle2->BackColor = System::Drawing::Color::White;
			dataGridViewCellStyle2->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			dataGridViewCellStyle2->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
			this->DirectionsGridView->RowsDefaultCellStyle = dataGridViewCellStyle2;
			this->DirectionsGridView->RowTemplate->DefaultCellStyle->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			this->DirectionsGridView->RowTemplate->DefaultCellStyle->BackColor = System::Drawing::Color::White;
			this->DirectionsGridView->RowTemplate->DefaultCellStyle->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->DirectionsGridView->RowTemplate->DefaultCellStyle->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
			this->DirectionsGridView->RowTemplate->ReadOnly = true;
			this->DirectionsGridView->Size = System::Drawing::Size(263, 195);
			this->DirectionsGridView->TabIndex = 26;
			// 
			// TagTxtBox
			// 
			this->TagTxtBox->BackColor = System::Drawing::Color::White;
			this->TagTxtBox->Location = System::Drawing::Point(103, 60);
			this->TagTxtBox->Name = L"TagTxtBox";
			this->TagTxtBox->ReadOnly = true;
			this->TagTxtBox->Size = System::Drawing::Size(172, 22);
			this->TagTxtBox->TabIndex = 28;
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label8->Location = System::Drawing::Point(12, 61);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(37, 17);
			this->label8->TabIndex = 27;
			this->label8->Text = L"Tags";
			// 
			// TimerDataGrid
			// 
			this->TimerDataGrid->AllowUserToAddRows = false;
			this->TimerDataGrid->AllowUserToDeleteRows = false;
			this->TimerDataGrid->BackgroundColor = System::Drawing::Color::White;
			this->TimerDataGrid->ColumnHeadersBorderStyle = System::Windows::Forms::DataGridViewHeaderBorderStyle::Single;
			this->TimerDataGrid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->TimerDataGrid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(3) {
				this->Label,
					this->mins, this->secs
			});
			this->TimerDataGrid->Location = System::Drawing::Point(308, 150);
			this->TimerDataGrid->Name = L"TimerDataGrid";
			this->TimerDataGrid->ReadOnly = true;
			dataGridViewCellStyle3->BackColor = System::Drawing::Color::White;
			dataGridViewCellStyle3->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			dataGridViewCellStyle3->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
			this->TimerDataGrid->RowsDefaultCellStyle = dataGridViewCellStyle3;
			this->TimerDataGrid->Size = System::Drawing::Size(204, 161);
			this->TimerDataGrid->TabIndex = 29;
			// 
			// Label
			// 
			this->Label->HeaderText = L"Label";
			this->Label->Name = L"Label";
			this->Label->ReadOnly = true;
			this->Label->Width = 60;
			// 
			// mins
			// 
			this->mins->HeaderText = L"Mins";
			this->mins->Name = L"mins";
			this->mins->ReadOnly = true;
			this->mins->Width = 50;
			// 
			// secs
			// 
			this->secs->HeaderText = L"Secs";
			this->secs->Name = L"secs";
			this->secs->ReadOnly = true;
			this->secs->Width = 50;
			// 
			// TimerLabelTxtBox
			// 
			this->TimerLabelTxtBox->Location = System::Drawing::Point(322, 348);
			this->TimerLabelTxtBox->Name = L"TimerLabelTxtBox";
			this->TimerLabelTxtBox->Size = System::Drawing::Size(100, 22);
			this->TimerLabelTxtBox->TabIndex = 30;
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label9->Location = System::Drawing::Point(428, 351);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(41, 17);
			this->label9->TabIndex = 31;
			this->label9->Text = L"Label";
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::Color::Transparent;
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->pictureBox1->Location = System::Drawing::Point(372, 9);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(161, 112);
			this->pictureBox1->TabIndex = 32;
			this->pictureBox1->TabStop = false;
			// 
			// Timers
			// 
			this->Timers->AutoSizeMode = System::Windows::Forms::DataGridViewAutoSizeColumnMode::AllCellsExceptHeader;
			this->Timers->HeaderText = L"Timer";
			this->Timers->MinimumWidth = 50;
			this->Timers->Name = L"Timers";
			// 
			// IngredientName
			// 
			this->IngredientName->HeaderText = L"Name";
			this->IngredientName->MinimumWidth = 110;
			this->IngredientName->Name = L"IngredientName";
			this->IngredientName->ReadOnly = true;
			this->IngredientName->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->IngredientName->Width = 110;
			// 
			// IngredientAmount
			// 
			this->IngredientAmount->AutoSizeMode = System::Windows::Forms::DataGridViewAutoSizeColumnMode::AllCellsExceptHeader;
			this->IngredientAmount->HeaderText = L"Amount";
			this->IngredientAmount->MinimumWidth = 110;
			this->IngredientAmount->Name = L"IngredientAmount";
			this->IngredientAmount->ReadOnly = true;
			this->IngredientAmount->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->IngredientAmount->Width = 110;
			// 
			// dataGridViewTextBoxColumn1
			// 
			this->dataGridViewTextBoxColumn1->HeaderText = L"Step";
			this->dataGridViewTextBoxColumn1->MinimumWidth = 219;
			this->dataGridViewTextBoxColumn1->Name = L"dataGridViewTextBoxColumn1";
			this->dataGridViewTextBoxColumn1->ReadOnly = true;
			this->dataGridViewTextBoxColumn1->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->dataGridViewTextBoxColumn1->Width = 219;
			// 
			// ViewRecipe
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::Control;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(533, 473);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->TimerLabelTxtBox);
			this->Controls->Add(this->TimerDataGrid);
			this->Controls->Add(this->TagTxtBox);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->DirectionsGridView);
			this->Controls->Add(this->IngredientsGridView);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->PrepTimeTxtBox);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->CloseButton);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->textBox3);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->RecipeNameTxtBox);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->RemoveTimerButton);
			this->Controls->Add(this->AddTimerButton);
			this->Font = (gcnew System::Drawing::Font(L"Segoe UI Semibold", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"ViewRecipe";
			this->Text = L"ViewRecipe";
			this->Load += gcnew System::EventHandler(this, &ViewRecipe::ViewRecipe_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->IngredientsGridView))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->DirectionsGridView))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->TimerDataGrid))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
private: System::Void ViewRecipe_Load(System::Object^  sender, System::EventArgs^  e)
	{
		RecipeNameTxtBox->Text = RecipeToView->RecipeName;
		PrepTimeTxtBox->Text = RecipeToView->PrepTime;
		TagTxtBox->Text = String::Join(", ", RecipeToView->Tags.ToArray());
		
		for each(Ingredient^ i in RecipeToView->Ingredients)
		{
			IngredientsGridView->Rows->Add(i->Label, i->Amount);
		}

		for each(String^ s in RecipeToView->Directions)
		{
			DirectionsGridView->Rows->Add(s);
		}

		DirectionsGridView->AutoResizeRows(DataGridViewAutoSizeRowsMode::AllCellsExceptHeaders);
		IngredientsGridView->AutoResizeRows(DataGridViewAutoSizeRowsMode::AllCellsExceptHeaders);
	}

private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e) 
{
	this->Close();
}

};
}
