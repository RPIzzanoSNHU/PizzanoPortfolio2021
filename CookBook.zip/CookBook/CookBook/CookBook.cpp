#include "CookBook.h"

namespace Recipes {
	using namespace System;
	using namespace System::IO;



	CookBook::CookBook()
	{
		this->Recipes = gcnew List<Recipe^>();
		this->AvailableRecipeNames = gcnew List<String^>();
		this->AvailableTags = gcnew List<String^>();
	}

#pragma region Loading Recipes via Search
	List<Recipe^>^ CookBook::LoadRecipesWithName(String^ Name)
	{
		List<Recipe^>^ ret = gcnew List<Recipe^>();

		if (!ReadRecipesListFile())
		{
			return ret;
		}

		if (!RecipeExists(Name))
		{
			return ret;
		}

		ret->Add(ReadRecipe(Name));

		return ret;
	}

	List<Recipe^>^ CookBook::LoadRecipesWithTag(String^ Tag)
	{
		// Check if the tag exists
		List<Recipe^>^ recipes = gcnew List<Recipe^>();
		if (!ReadTagsListFile())
		{
			return recipes;
		}

		if (!TagExists(Tag))
		{
			return recipes;
		}

		// Read in all recipes with that tag
		List<String^>^ RecipesInTag = ReadTag(Tag);

		if(!ReadRecipesListFile())
		for each (String^ s in RecipesInTag)
		{
			if (!RecipeExists(s))
			{
				continue;
			}

			recipes->Add(ReadRecipe(s));

		}

		return gcnew List<Recipe^>();
	}

	List<Recipe^>^ CookBook::LoadAllRecipes()
	{
		List<Recipe^>^ recipes = gcnew List<Recipe^>();

		if (!ReadRecipesListFile())
		{
			return recipes;
		}

		for each(String^ s in AvailableRecipeNames)
		{
			recipes->Add(ReadRecipe(s));
		}

		return recipes;
	}
#pragma endregion

#pragma region Adding a new recipe *Coded*
	bool CookBook::AddRecipe(Recipe^ recipe)
	{
		// Create the new file
		if (!CreateRecipeFileFromRecipe(recipe))
		{
			return false;
		}

		// Update the master list to include this recipe
		if (!UpdateRecipeListFile(recipe->RecipeName, true))
		{
			return false;
		}

		// Add the recipe to all tags it has
		for each(String^ s in recipe->Tags)
		{
			if (!UpdateTag(s->ToLower() , recipe->RecipeName, true))
			{
				return false;
			}
		}

		return true;
	}

	bool CookBook::CreateRecipeFileFromRecipe(Recipe^ recipe)
	{
		String^ filename = "./RequiredFiles/Recipes/" + recipe->RecipeName->Replace(" ", "_") + ".rec";

		try
		{
			StreamWriter^ OutStream = gcnew StreamWriter(filename);

			#pragma region Write Recipe Name
			OutStream->Write("<name>");
			OutStream->Write(recipe->RecipeName);
			OutStream->WriteLine("</name>");
			#pragma endregion

			#pragma region Write Prep Time
			OutStream->Write("<prep>");
			OutStream->Write(recipe->PrepTime);
			OutStream->WriteLine("</prep>");
			#pragma endregion

			#pragma region Write Description
			OutStream->Write("<description>");
			OutStream->Write(recipe->Description);
			OutStream->WriteLine("</description>");
			#pragma endregion

			#pragma region Write Tags
			for each(String^ s in recipe->Tags)
			{
				OutStream->Write("<tag>");
				OutStream->Write(s);
				OutStream->WriteLine("</tag>");
			}
			#pragma endregion

			#pragma region Write Ingredients
			for each(Ingredient^ i in recipe->Ingredients)
			{
				OutStream->Write("<ingredient>\n\t<ingredientName>");
				OutStream->Write(i->Label);
				OutStream->Write("</ingredientName>\n\t<ingredientAmount>");
				OutStream->Write(i->Amount);
				OutStream->WriteLine("</ingredientAmount>\n</ingredient>");
			}
			#pragma endregion

			#pragma region Write Directions
			for each(String^ s in recipe->Directions)
			{
				OutStream->Write("<step>");
				OutStream->Write(s);
				OutStream->WriteLine("</step>");
			}
			#pragma endregion

			OutStream->Close();
		}
		catch (Exception^ E)
		{
			Console::WriteLine(E->Message);
			return false;
		}

		return true;
	}

	bool CookBook::UpdateRecipeListFile(String^ RecipeName, bool AddRecipe)
	{
		if (!ReadRecipesListFile())
		{
			return false;
		}

		if (RecipeExists(RecipeName))
		{
			if (AddRecipe)
			{
				return true;
			}
			else
			{
				AvailableRecipeNames->Remove(RecipeName);
				return WriteRecipesToRecipeList();
			}
		}
		else
		{
			if (AddRecipe)
			{
				AvailableRecipeNames->Add(RecipeName);
				if (!WriteRecipesToRecipeList()) {
					return false;
				}
			}
			else
			{
				return true;
			}
		}

		return true;
	}

	bool CookBook::WriteRecipesToRecipeList()
	{
		String^ filename = "./RequiredFiles/Recipes/recipe_dir.txt";

		try
		{
			StreamWriter^ OutStream = gcnew StreamWriter(filename);

			for each(String^ s in AvailableRecipeNames)
			{
				OutStream->WriteLine(s);
			}

			OutStream->Close();
		}
		catch (Exception^ E)
		{
			Console::WriteLine(E->Message);
			return false;
		}

		return true;
	}
#pragma endregion

#pragma region Update a recipe *Coded*
	bool CookBook::UpdateRecipe(Recipe^ recipe, String^ OldRecipeName)
	{
		/*
			TODO: Can be made more efficient by passing the new recipe and the old recipe and only changing fields
			that differ. This would reduce the amount of file opening, reading, writing and deleting.
		*/
		if (!RemoveRecipe(OldRecipeName))
		{
			return false;
		}

		if (!AddRecipe(recipe))
		{
			return false;
		}

		return true;
	}
#pragma endregion

#pragma region Delete a Recipe *Coded*
	bool CookBook::RemoveRecipe(String^ RecipeName)
	{
		// Read in the list of recipes
		if (!ReadRecipesListFile())
		{
			return false;
		}

		// Check if the recipe we want exists
		if (!RecipeExists(RecipeName))
		{
			return false;
		}

		// Read in the recipe so we can access what tags it is connected to
		Recipe^ RecipeToBeDeleted = ReadRecipe(RecipeName);

		// Delete the Recipe from the recipe list file
		UpdateRecipeListFile(RecipeName, false);

		// Remove recipe from all tags
		for each (String^ s in RecipeToBeDeleted->Tags)
		{
			if (!UpdateTag(s, RecipeName, false))
			{
				return false;
			}
		}

		// Remove the Recipe File
		if (!DeleteRecipeFile(RecipeName))
		{
			return false;
		}

		return true;
	}

	bool CookBook::DeleteRecipeFile(String^ RecipeName)
	{
		String^ filename = "./RequiredFiles/Recipes/" + RecipeName->Replace(" ", "_") + ".rec";

		try
		{
			File::Delete(filename);
		}
		catch(Exception^ E)
		{
			Console::WriteLine(E->Message);
			return false;
		}
		return true;
	}
#pragma endregion

#pragma region Update a tag *Coded*
	bool CookBook::UpdateTag(String^ Tag, String^ RecipeName, bool AddRecipe)
	{
		if (!ReadTagsListFile())
		{
			return false;
		}

		if (TagExists(Tag))
		{
			List<String^>^ RecipesWithTag = ReadTag(Tag);

			if (AddRecipe)
			{
				if (RecipesWithTag->Contains(RecipeName))
				{
					return true;
				}
				else
				{
					RecipesWithTag->Add(RecipeName);
					RecipesWithTag->Sort();
					return WriteRecipesToTag(Tag, RecipesWithTag);
				}
			}
			else
			{
				if (RecipesWithTag->Contains(RecipeName))
				{
					RecipesWithTag->Remove(RecipeName);
					return WriteRecipesToTag(Tag, RecipesWithTag);
				}
				else
				{
					return true;
				}
			}
		}
		else
		{
			if (AddRecipe)
			{
				List<String^>^ RecipesWithTag = ReadTag(Tag);
				RecipesWithTag->Add(RecipeName);
				RecipesWithTag->Sort();
				return WriteRecipesToTag(Tag, RecipesWithTag);
			}
			else
			{
				return true;
			}
		}
		
	}

	bool CookBook::WriteRecipesToTag(String^ Tag, List<String ^>^ Recipes)
	{
		String^ filename = "./RequiredFiles/Tags/" + Tag->Replace(" ", "_") + ".ret";

		try
		{
			StreamWriter^ OutStream = gcnew StreamWriter(filename);

			for each(String^ s in Recipes)
			{
				OutStream->WriteLine(s);
			}

			OutStream->Close();

		}
		catch (Exception^ E)
		{
			Console::WriteLine(E->Message);
			return false;
		}

		return true;
	}
#pragma endregion

#pragma region File Reading (Tags and Recipes) *Coded*
	bool CookBook::ReadTagsListFile()
	{
		AvailableTags->Clear();
		String ^ filename = "./RequiredFiles/Tags/tag_dir.txt";

		try {
			StreamReader^ file = File::OpenText(filename);

			String^ tag;

			//Read in line by line
			while ((tag = file->ReadLine()) != nullptr)
			{
				this->AvailableTags->Add(tag->Trim());
			}

			file->Close();
		}
		catch (Exception^ E)
		{
			Console::WriteLine(E->Message);
			return false;
		}

		return true;
	}

	bool CookBook::ReadRecipesListFile()
	{
		AvailableRecipeNames->Clear();
		String^ filename = "./RequiredFiles/Recipes/recipe_dir.txt";

		try {
			StreamReader^ file = File::OpenText(filename);

			String^ recipe;

			//Read in line by line
			while ((recipe = file->ReadLine()) != nullptr)
			{
				this->AvailableRecipeNames->Add(recipe->Trim());
			}

			file->Close();
		}
		catch (Exception^ E)
		{
			Console::WriteLine(E->Message);
			return false;
		}

		return true;
	}

	Recipe^ CookBook::ReadRecipe(String^ RecipeName)
	{
		Recipe^ returnRecipe = gcnew Recipe();

		String^ filename = RecipeName->Replace(" ", "_") + ".rec";

		//Open the file and read in the contents
		try
		{
			StreamReader^ file = File::OpenText("./RequiredFiles/Recipes/" + filename);

			String^ line;

			while ((line = file->ReadLine()) != nullptr)
			{
				#pragma region Read in Ingredient
								if (line->Contains("<ingredient>"))
								{
									Ingredient^ ingredient = gcnew Ingredient();
									while ((line = file->ReadLine()) != nullptr)
									{
										// We finished parsing this ingredient, save it and move on
										if (line->Contains("</ingredient>")) {
											returnRecipe->AddIngredient(ingredient);
											break;
										}

										if (line->Contains("<ingredientName>"))
										{
											// Remove the tags
											line = line->Replace("<ingredientName>", "");
											line = line->Replace("</ingredientName>", "");

											ingredient->Label = line;
										}

										if (line->Contains("<ingredientAmount>"))
										{
											// Remove the tags
											line = line->Replace("<ingredientAmount>", "");
											line = line->Replace("</ingredientAmount>", "");

											ingredient->Amount = line;
										}
									}
								}
				#pragma endregion

				#pragma region Read in directions
								if (line->Contains("<step>") && line->Contains("</step>"))
								{
									//Remove the tags
									line = line->Replace("<step>", "");
									line = line->Replace("</step>", "");
									returnRecipe->AddStep(line);
								}
				#pragma endregion

				#pragma region Read in tags 
								if (line->Contains("<tag>") && line->Contains("</tag>"))
								{
									//Remove the tags
									line = line->Replace("<tag>", "");
									line = line->Replace("</tag>", "");
									returnRecipe->Tags.Add(line);
								}
				#pragma endregion

				#pragma region Read Name
								if (line->Contains("<name>") && line->Contains("</name>"))
								{
									line = line->Replace("<name>", "");
									line = line->Replace("</name>", "");
									returnRecipe->RecipeName = line;
								}
				#pragma endregion

				#pragma region Read in Prep Time
								if (line->Contains("<prep>") && line->Contains("</prep>"))
								{
									line = line->Replace("<prep>", "");
									line = line->Replace("</prep>", "");

									returnRecipe->PrepTime = line;
								}
				#pragma endregion

				#pragma region Read in Description
								if (line->Contains("<description>") && line->Contains("</description>"))
								{
									line = line->Replace("<description>", "");
									line = line->Replace("</description>", "");

									returnRecipe->Description = line;
								}
				#pragma endregion
			}

			file->Close();

		}
		catch (Exception^ E)
		{
			Console::WriteLine(E->Message);
			Recipe^ returnRecipe = nullptr;
			return returnRecipe;
		}

		return returnRecipe;
	}

	List<String^>^ CookBook::ReadTag(String^ Tag)
	{
		// For this function we assume the user checks that the tag exists
		List<String^>^ returnList = gcnew List<String^>();

		String^ filename = Tag->Replace(" ", "_") + ".ret";

		// Open the file and read in the contents
		try
		{
			StreamReader^ file = File::OpenText("./RequiredFiles/Tags/" + filename);

			String^ recipe;

			//Read in line by line
			while ((recipe = file->ReadLine()) != nullptr)
			{
				returnList->Add(recipe->Replace("_", " "));
			}

			file->Close();
		}
		catch (Exception^ E)
		{
			//Return nicely with an empty list
			Console::WriteLine(E->Message);
			returnList->Clear();
			return returnList;
		}

		return returnList;
	}

	bool CookBook::RecipeExists(String^ RecipeName)
	{
		return AvailableRecipeNames->Contains(RecipeName);
	}

	bool CookBook::TagExists(String^ Tag)
	{
		return AvailableTags->Contains(Tag);
	}

	bool CookBook::RecipeHasTag(String^ RecipeName, String^ Tag)
	{
		// Update our lists
		if (!ReadRecipesListFile())
		{
			return false;
		}

		if (!ReadTagsListFile())
		{
			return false;
		}

		// Verify the tag exists
		if (!TagExists(Tag))
		{
			return false;
		}

		// Verify the Recipe Exists
		if (!RecipeExists(RecipeName))
		{
			return false;
		}

		// Read in the recipe
		Recipe^ TargetRecipe = ReadRecipe(RecipeName);

		// Verify the Recipe contains the tag
		if (!TargetRecipe->Tags.Contains(Tag))
		{
			return false;
		}

		// Read in the Tag
		List<String^>^ RecipesWithTag = ReadTag(Tag);

		// Verify the Tag file has the recipe listed
		if (!RecipesWithTag->Contains(Tag))
		{
			return false;
		}

		// If we make it this far, the recipe definitely has the tag
		return true;
	}
#pragma endregion
}