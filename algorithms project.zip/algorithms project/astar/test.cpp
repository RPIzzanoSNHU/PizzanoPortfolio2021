//Ryan Pizzano
//Algorithms
//Big Programming Project: A* V Dijkstra
#include <iostream>
#include <iomanip>
#include <queue>
#include <string>
#include <math.h>
#include <ctime>
using namespace std;

const int n = 60; // horizontal size of the map
const int m = 60; // vertical size size of the map
static int map[n][m];
static int closedNode[n][m]; // map of closed tried nodes
static int openNodes[n][m]; // map of open untried nodes
static int dir_map[n][m]; // directions that can be traversed in the map
const int dir = 8; // number of possible directions to go at any position
static int Xaxis[dir] = { 1, 1, 0, -1, -1, -1, 0, 1 };
static int Yaxis[dir] = { 0, 1, 1, 1, 0, -1, -1, -1 };

class node
{
	// current position
	int xPosition;
	int yPosition;
	int level;// distance already travelled to a node
	
	int priority;  //  priority is level and the remaining distance estimate,  smaller means higher priority

public:
	node(int xp, int yp, int d, int p)
	{
		xPosition = xp; yPosition = yp; level = d; priority = p;
	}

	int getxPos() const { return xPosition; }
	int getyPos() const { return yPosition; }
	int getLevel() const { return level; }
	int getPriority() const { return priority; }

	void updatePriority(const int & xDest, const int & yDest)
	{
		priority = level + heuristic(xDest, yDest) * 10; //A*
		
	}

	// give better priority to going straight instead of diagonally
	void nextLevel(const int & i) // i: direction
	{
		level += (dir == 8 ? (i % 2 == 0 ? 10 : 14) : 10);
	}

	// Gets the heuritstic
	const int & heuristic(const int & xDest, const int & yDest) const
	{
		static int xd, yd, d;
		xd = xDest - xPosition;
		yd = yDest - yPosition;
		// switch between the two "d =" to Switch between Dijkstra and A*
		d = static_cast<int>(sqrt(xd*xd + yd * yd)); 
		//d = 0;

		return(d);
		//return 0;
	}
};

// Determine priority (in the priority queue)
bool operator<(const node & a, const node & b)
{
	return a.getPriority() > b.getPriority();
}

// A-star algorithm.
string aStarAlg(const int & xStart, const int & yStart,
	const int & xFinish, const int & yFinish)
{
	static priority_queue<node> priorityq[2]; // list of open untried nodes
	static int priorityqi; // priority queue index
	static node* n0;
	static node* m0;
	static int i, j, x, y, xdx, ydy;
	static char c;
	priorityqi = 0;

	for (y = 0; y < m; y++)// reset the node maps
	{
		for (x = 0; x < n; x++)
		{
			closedNode[x][y] = 0;
			openNodes[x][y] = 0;
		}
	}

	
	n0 = new node(xStart, yStart, 0, 0);// create the start node and push into list of open nodes
	n0->updatePriority(xFinish, yFinish);
	priorityq[priorityqi].push(*n0);
	openNodes[x][y] = n0->getPriority(); // mark any open nodes

	
	while (!priorityq[priorityqi].empty())// A* search
	{
		
		n0 = new node(priorityq[priorityqi].top().getxPos(), priorityq[priorityqi].top().getyPos(),// get the current node with the highest priority from the list of open nodes
			priorityq[priorityqi].top().getLevel(), priorityq[priorityqi].top().getPriority());

		x = n0->getxPos(); y = n0->getyPos();

		priorityq[priorityqi].pop(); // remove the node from the open list
		openNodes[x][y] = 0;
	
		closedNode[x][y] = 1;	// mark a node closed

		if (x == xFinish && y == yFinish)
		{
			// generate the path by following the directions
			string path = "";
			while (!(x == xStart && y == yStart))
			{
				j = dir_map[x][y];
				c = '0' + (j + dir / 2) % dir;
				path = c + path;
				x += Xaxis[j];
				y += Yaxis[j];
			}

			// garbage collection and tree clean up
			delete n0;
			
			while (!priorityq[priorityqi].empty()) priorityq[priorityqi].pop();
			return path;
		}

		// generate moves in all possible directions
		for (i = 0; i < dir; i++)
		{
			xdx = x + Xaxis[i]; ydy = y + Yaxis[i];

			if (!(xdx<0 || xdx>n - 1 || ydy<0 || ydy>m - 1 || map[xdx][ydy] == 1
				|| closedNode[xdx][ydy] == 1))
			{
				// generate a child node
				m0 = new node(xdx, ydy, n0->getLevel(),
					n0->getPriority());
				m0->nextLevel(i);
				m0->updatePriority(xFinish, yFinish);

				
				if (openNodes[xdx][ydy] == 0)// if it is not in the open list then add into that
				{
					openNodes[xdx][ydy] = m0->getPriority();
					priorityq[priorityqi].push(*m0);
					dir_map[xdx][ydy] = (i + dir / 2) % dir;// mark its parent node direction
				}
				else if (openNodes[xdx][ydy] > m0->getPriority())
				{
					
					openNodes[xdx][ydy] = m0->getPriority();// update priority
					dir_map[xdx][ydy] = (i + dir / 2) % dir;// update parent direction 

					
					
					while (!(priorityq[priorityqi].top().getxPos() == xdx &&
						priorityq[priorityqi].top().getyPos() == ydy))
					{
						priorityq[1 - priorityqi].push(priorityq[priorityqi].top());
						priorityq[priorityqi].pop();
					}
					priorityq[priorityqi].pop(); // remove the wanted node

					// empty the larger size priority queue to the smaller one
					if (priorityq[priorityqi].size() > priorityq[1 - priorityqi].size()) priorityqi = 1 - priorityqi;
					while (!priorityq[priorityqi].empty())
					{
						priorityq[1 - priorityqi].push(priorityq[priorityqi].top());
						priorityq[priorityqi].pop();
					}
					priorityqi = 1 - priorityqi;
					priorityq[priorityqi].push(*m0); // add the better node instead
				}
				else delete m0; 
			}
		}
		delete n0; // garbage collection
	}
	return ""; // no route found
}

int main()
{
	srand(time(NULL));

	// create empty map
	for (int y = 0; y < m; y++)
	{
		for (int x = 0; x < n; x++) map[x][y] = 0;
	}

	// plus pattern as an obstacle
	for (int x = n / 8; x < n * 7 / 8; x++)
	{
		map[x][m / 2] = 1;
	}
	for (int y = m / 8; y < m * 7 / 8; y++)
	{
		map[n / 2][y] = 1;
	}

	//  select start and finish locations
	int xA =22, yA=14, xB=55, yB=52;

	cout << "Map Size (X,Y): " << n << "," << m << endl;
	cout << "Start: " << xA << "," << yA << endl;
	cout << "Finish: " << xB << "," << yB << endl;
	clock_t start = clock();
	string route = aStarAlg(xA, yA, xB, yB);
	if (route == "") cout << "An empty route generated!" << endl;
	clock_t end = clock();
	double time_elapsed = double(end - start);
	cout << "Time to calculate the route (ms): " << time_elapsed << endl;
	
	if (route.length() > 0)// follow the route on the map and display it 
	{
		int j; char c;
		int x = xA;
		int y = yA;
		map[x][y] = 2;
		for (int i = 0; i < route.length(); i++)
		{
			c = route.at(i);
			j = atoi(&c);
			x = x + Xaxis[j];
			y = y + Yaxis[j];
			map[x][y] = 3;
		}
		map[x][y] = 4;

		
		for (int y = 0; y < m; y++)// display the completed route on the map
		{
			for (int x = 0; x < n; x++)
				if (map[x][y] == 0)
					cout << ".";
				else if (map[x][y] == 1)
					cout << "B"; //blocked path
				else if (map[x][y] == 2)
					cout << "S"; //start of path
				else if (map[x][y] == 3)
					cout << "R"; //route taken
				else if (map[x][y] == 4)
					cout << "F"; //End of path
			cout << endl;
		}
	}
	getchar();
	return(0);
}